#parse("File Header.java")

/**
 * ${description}
 *
 * @author LiYuanHao
 * @date ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}:${SECOND}
 */
module #[[$MODULE_NAME$]]# {
}